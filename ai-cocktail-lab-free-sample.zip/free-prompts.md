﻿# Drink Photography Prompts — FREE SAMPLE (5 of 50)

Structured 7-pillar JSON prompts for Google Imagen (Nano Banana). Paste the JSON
block as your prompt; to shoot YOUR drink, edit only the `subject` block — the rest
is a pre-built lighting/set recipe. The full pack has 50 across five style families:
GUMROAD_LINK_PLACEHOLDER

---

### 01 · Hard-Light Editorial Coupe

```json
{
  "subject": {
    "product": "classic daiquiri in a chilled Nick & Nora glass",
    "details": "crystal-clear pale straw liquid, frost line on the stem, razor-thin lime wheel garnish",
    "state": "freshly strained, micro-bubbles still settling on the surface"
  },
  "action": {
    "primary": "static hero pose",
    "secondary": "single bead of condensation tracking down the bowl"
  },
  "environment": {
    "surface": "seamless matte terracotta studio sweep",
    "background": "same terracotta, uninterrupted color field",
    "props": "one hard geometric shadow from an unseen window frame"
  },
  "medium": {
    "style": "high-fashion editorial product photography",
    "lens": "85mm f/8, tack sharp",
    "reference": "Bon Appétit drinks editorial, hard-light era"
  },
  "composition": {
    "focus": "glass rim and lime wheel",
    "framing": "centered, generous negative space above for type",
    "angle": "straight-on at glass height",
    "depth_of_field": "deep, everything crisp"
  },
  "lighting": {
    "primary": "single hard directional sunlight from upper left",
    "secondary": "no fill, let shadows go graphic",
    "atmosphere": "bold, gallery-clean, high contrast",
    "reflections": "one specular hotspot on the bowl, sharp caustic light pool through the stem"
  },
  "intent": {
    "usage": "menu cover, brand hero image",
    "aspect_ratio": "4:5",
    "audience": "craft cocktail drinkers 25-45"
  }
}
```

---

### 03 · Neon Backbar Old Fashioned

```json
{
  "subject": {
    "product": "old fashioned in a heavy rocks glass over one oversized clear ice cube",
    "details": "deep amber whiskey, wide expressed orange peel resting on the cube, glass showing honest fingerprints",
    "state": "two sips taken, ice cube starting to soften at the edges"
  },
  "action": {
    "primary": "resting on the bar mid-conversation",
    "secondary": "faint cigarette-era haze in the air catching the neon"
  },
  "environment": {
    "surface": "decades-old lacquered oak bar top with ring stains and chipped edge",
    "background": "out-of-focus backbar bottles and a buzzing red-and-blue neon beer sign",
    "props": "crumpled cocktail napkin, worn brass bar rail bottom of frame"
  },
  "medium": {
    "style": "cinematic night photography, 35mm film",
    "grain": "visible Cinestill 800T halation and grain",
    "lens": "50mm f/1.8",
    "reference": "neon-noir film stills"
  },
  "composition": {
    "focus": "orange peel and front face of the ice cube",
    "framing": "medium close-up, bar top leading into frame",
    "angle": "seated drinker's eye level",
    "depth_of_field": "shallow, backbar melts into neon bokeh"
  },
  "lighting": {
    "primary": "red-blue neon glow from behind the glass",
    "secondary": "warm tungsten spill from an unseen bar lamp camera-left",
    "atmosphere": "late-night, lived-in, nostalgic",
    "reflections": "neon doubled in the whiskey and the wet lacquer"
  },
  "intent": {
    "usage": "Instagram feed, moody brand content",
    "aspect_ratio": "4:5",
    "audience": "whiskey drinkers, night-out crowd"
  }
}
```

---

### 05 · Swizzle in Crushed Ice

```json
{
  "subject": {
    "product": "rum swizzle in a tall footed pilsner glass packed with crushed ice",
    "details": "ombre gradient from deep garnet falernum base to golden rum top, dome of crushed ice above the rim",
    "state": "frost-armored glass, fully swizzled, straw-ready"
  },
  "action": {
    "primary": "hero pose mid-service",
    "secondary": "mint sprig garnish still quivering, dust of fresh nutmeg falling"
  },
  "environment": {
    "surface": "woven lauhala mat over dark teak",
    "background": "carved tiki mugs and bamboo wall out of focus, one string of amber patio bulbs",
    "props": "swizzle stick, spent lime shell, brass jigger"
  },
  "medium": {
    "style": "warm tropical product photography",
    "lens": "60mm f/2.8",
    "reference": "modern tiki bar menu photography"
  },
  "composition": {
    "focus": "ice dome and mint",
    "framing": "vertical hero, full glass with headroom for garnish",
    "angle": "slightly low, glass towers",
    "depth_of_field": "shallow-medium, bamboo softly readable"
  },
  "lighting": {
    "primary": "warm key from camera right mimicking sunset through window",
    "secondary": "amber bulb bokeh as background accent",
    "atmosphere": "humid, golden, escapist",
    "reflections": "glitter across the crushed ice facets"
  },
  "intent": {
    "usage": "menu and Instagram",
    "aspect_ratio": "4:5",
    "audience": "tiki and rum enthusiasts"
  }
}
```

---

### 07 · Citrus Oil Expression Macro

```json
{
  "subject": {
    "product": "bartender's fingers expressing an orange peel over a coupe",
    "details": "peel folded skin-side out, visible spray of essential oil droplets frozen mid-air above the drink",
    "state": "the exact instant of expression"
  },
  "action": {
    "primary": "citrus oils bursting from the peel",
    "secondary": "micro-droplets catching light like sparks over the liquid surface"
  },
  "environment": {
    "surface": "dark walnut bar top, soft focus",
    "background": "near-black falloff",
    "props": "none, all attention on the spray"
  },
  "medium": {
    "style": "high-speed macro photography",
    "lens": "100mm macro f/5.6, flash-frozen motion",
    "reference": "liquid high-speed studio work"
  },
  "composition": {
    "focus": "oil droplet cloud",
    "framing": "extreme close-up, hands cropped at wrist",
    "angle": "side-on, backlit spray",
    "depth_of_field": "razor thin on the droplet plane"
  },
  "lighting": {
    "primary": "hard backlight rimming every droplet",
    "secondary": "soft warm fill on the drink surface",
    "atmosphere": "dramatic, technical, reverent",
    "reflections": "droplets as individual points of light"
  },
  "intent": {
    "usage": "hero content, technique reel cover",
    "aspect_ratio": "4:5",
    "audience": "cocktail nerds and industry"
  }
}
```

---

### 10 · Overhead Espresso Martini Flat-Lay

```json
{
  "subject": {
    "product": "espresso martini in a coupe, shot dead overhead",
    "details": "dense tan foam cap with three coffee beans centered, perfect circle of the glass rim",
    "state": "foam fully set, crema-like surface texture visible"
  },
  "action": {
    "primary": "static geometric flat-lay",
    "secondary": "a few scattered coffee beans and a dusting of fine espresso grounds on the surface beside the glass"
  },
  "environment": {
    "surface": "cool dark slate with natural cleft texture",
    "background": "the surface is the background",
    "props": "small brass jigger lying at 4 o'clock, torn corner of a paper menu at top edge"
  },
  "medium": {
    "style": "graphic overhead food-editorial photography",
    "lens": "50mm at f/7.1, shot from directly above",
    "reference": "coffee-culture magazine spreads"
  },
  "composition": {
    "focus": "foam surface texture",
    "framing": "glass off-center on rule-of-thirds point",
    "angle": "perfect 90-degree overhead",
    "depth_of_field": "deep enough for all surface props"
  },
  "lighting": {
    "primary": "soft window light from top of frame",
    "secondary": "subtle negative fill bottom of frame for foam contrast",
    "atmosphere": "calm, caffeinated, graphic",
    "reflections": "matte overall, tiny gloss ring where foam meets glass"
  },
  "intent": {
    "usage": "Instagram feed, menu detail",
    "aspect_ratio": "1:1",
    "audience": "espresso martini era drinkers"
  }
}
```

